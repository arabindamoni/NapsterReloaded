Inspired by napster it is a simple java swing application to share music files.

How to use?
This software runs in server-client model.
The same application can be used as server and client. 
Server must use 127.0.0.1 or other localhost ip address and click connect.
After server has started, clients can connect using server's ip address.
Put mp3 files you want to share in the shared folder.
Put server's ip address and connect.
Search by title or artist and download chosen files. 
Downloaded songs will be in Downloaded folder.
Rest is limitless sharing and fun. :)